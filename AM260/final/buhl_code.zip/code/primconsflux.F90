module primconsflux

#include "definition.h"
  
  use grid_data
  use sim_data, only : sim_gamma, sim_smallPres
  use eos, only : eos_cell
  
contains

  subroutine prim2cons(V,U)
    implicit none
    real, dimension(NUMB_VAR), intent(IN)  :: V
    real, dimension(NSYS_VAR), intent(OUT) :: U

    real :: ekin, eint

    U(DENS_VAR) = V(DENS_VAR)
    U(MOMX_VAR) = V(DENS_VAR)*V(VELX_VAR)
    U(ENER_VAR) = 0.5*V(DENS_VAR)*V(VELX_VAR)**2 + V(PRES_VAR)/(V(GAME_VAR)-1.)
  end subroutine prim2cons


  subroutine cons2prim(U,V)
    implicit none
    real, dimension(NSYS_VAR), intent(IN)  :: U
    real, dimension(NUMB_VAR), intent(OUT) :: V
    real :: eint, ekin, pres
    
    V(DENS_VAR) = max(U(DENS_VAR),sim_smallpres)
    V(VELX_VAR) = U(MOMX_VAR)/V(DENS_VAR)
    ekin = 0.5*V(DENS_VAR)*V(VELX_VAR)**2
    eint = max(U(ENER_VAR) - ekin, sim_smallPres)/V(DENS_VAR) !eint=rho*e
    V(EINT_VAR) = eint
    ! get pressure by calling eos
    call eos_cell(U(DENS_VAR),eint,sim_gamma,pres)
    V(PRES_VAR) = pres
    V(GAMC_VAR) = sim_gamma
    V(GAME_VAR) = sim_gamma
    
  end subroutine cons2prim

  subroutine prim2flux(V,Flux)
    implicit none
    real, dimension(NUMB_VAR), intent(IN)  :: V
    real, dimension(NSYS_VAR), intent(OUT) :: Flux

    real :: ekin,eint,ener
    
    Flux(DENS_VAR) = V(DENS_VAR)*V(VELX_VAR)
    Flux(MOMX_VAR) = Flux(DENS_VAR)*V(VELX_VAR) + V(PRES_VAR)
    ener = 0.5*V(DENS_VAR)*V(VELX_VAR)**2 + V(PRES_VAR)/(V(GAME_VAR)-1.)
    Flux(ENER_VAR) = V(VELX_VAR)*(ener + V(PRES_VAR))
    
  end subroutine prim2flux

  subroutine cons2flux(U,Flux)
    implicit none
    real, dimension(NSYS_VAR), intent(IN)  :: U
    real, dimension(NSYS_VAR), intent(OUT) :: Flux

    real :: ekin,eint,ener,pres,velx
    
    Flux(DENS_VAR) = U(MOMX_VAR)
    velx = U(MOMX_VAR)/U(DENS_VAR)
    ekin = 0.5*U(MOMX_VAR)*velx
    eint = max(U(ENER_VAR) - ekin, sim_smallPres)/U(DENS_VAR) !eint=rho*e
    ! get pressure by calling eos
    call eos_cell(U(DENS_VAR),eint,sim_gamma,pres)
    Flux(MOMX_VAR) = velx*U(MOMX_VAR) + pres
    Flux(ENER_VAR) = velx*(U(ENER_VAR) + pres)

  end subroutine cons2flux
  
end module primconsflux
